#!/bin/bash

echo "====== SecureText Encryption Tool ======"

if [ -z "$1" ]; then
    echo "Usage: ./encrypt.sh filename.txt"
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "Error: File not found!"
    exit 1
fi

mkdir -p secrets

read -sp "Enter password (min 8 characters): " password
echo

if [ ${#password} -lt 8 ]; then
    echo "Password must be at least 8 characters!"
    exit 1
fi

read -sp "Confirm password: " confirm
echo

if [ "$password" != "$confirm" ]; then
    echo "Passwords do not match!"
    exit 1
fi

openssl enc -aes-256-cbc -pbkdf2 -salt -in "$1" -out "secrets/$1.enc" -k "$password"

if [ $? -eq 0 ]; then
    echo "Encryption successful!"
    echo "Encrypted file: secrets/$1.enc"
else
    echo "Encryption failed."
fi
