# SecureText – Portable Linux Encryption Tool

## Developed On:
Omarchy (Arch-based Linux)

## Compatible With:
- Kali Linux
- Ubuntu
- Debian
- Arch Linux

## Objective:
To implement AES-256 encryption using OpenSSL in Linux.

## Features:
- AES-256-CBC encryption
- PBKDF2 key derivation
- Salt protection
- Password confirmation
- Error handling
- Portable across Linux distributions

## Usage:

1. Run installer:
   ./install.sh

2. Encrypt file:
   ./encrypt.sh filename.txt

3. Decrypt file:
   ./decrypt.sh filename.txt.enc

## Encryption Method:
OpenSSL AES-256-CBC with PBKDF2
