#!/bin/bash

echo "Checking OpenSSL installation..."

if ! command -v openssl &> /dev/null
then
    echo "OpenSSL not found."
    echo "Install it using:"
    echo "Kali/Ubuntu: sudo apt install openssl"
    echo "Arch/Omarchy: sudo pacman -S openssl"
    exit 1
fi

chmod +x encrypt.sh decrypt.sh

echo "Installation complete!"
echo "You can now run:"
echo "./encrypt.sh filename.txt"
