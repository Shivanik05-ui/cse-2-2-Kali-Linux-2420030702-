#!/bin/bash

echo "====== SecureText Decryption Tool ======"

if [ -z "$1" ]; then
    echo "Usage: ./decrypt.sh filename.txt.enc"
    exit 1
fi

if [ ! -f "secrets/$1" ]; then
    echo "Encrypted file not found inside secrets folder!"
    exit 1
fi

read -sp "Enter password: " password
echo

openssl enc -aes-256-cbc -d -pbkdf2 -in "secrets/$1" -out "decrypted_${1%.enc}" -k "$password"

if [ $? -eq 0 ]; then
    echo "Decryption successful!"
    echo "Decrypted file: decrypted_${1%.enc}"
else
    echo "Wrong password or corrupted file."
fi
